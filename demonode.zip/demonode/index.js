const express = require('express');
const app = express();
const port = 80;

app.get('/', (req, res) => {
    res.send('Hello World,this is responce from port 80 and  express app');
});


app.listen(port, () => console.log(`nodejs Server is starting on port 80`))
